﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IssueTrackerTests.Helpers
{
    public class Package
    {
        public string Id { get; set; }
        public string Version { get; set; }
        public string TargetFramework { get; set; }
    }
}
